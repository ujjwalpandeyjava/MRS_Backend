package pandey.ujjwal.MovierReviewer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MovierReviewerApplication {

	public static void main(String[] args) {
		SpringApplication.run(MovierReviewerApplication.class, args);
	}

}
