package pandey.ujjwal.MovierReviewer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovierReviewerApplicationTests {

	@Test
	void contextLoads() {
	}

}
